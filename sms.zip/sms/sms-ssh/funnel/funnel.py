# funnel.py
import requests

def send_discord_webhook(webhook_url, title, description, color=3447003):
    data = {
        "embeds": [
            {
                "title": title,
                "description": description,
                "color": color
            }
        ]
    }
    headers = {'Content-Type': 'application/json'}
    requests.post(webhook_url, json=data, headers=headers)

def send_phone_request(phone_number):
    url = "https://pbkorea.com/web/api/verification/phone/request"
    headers = {
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
        "Content-Type": "application/json",
        "Cookie": "i18n_redirected=ko; HIDE_POPUP_TODAY=false",
        "Origin": "https://pbkorea.com",
        "Referer": "https://pbkorea.com/",
        "Sec-CH-UA": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        "Sec-CH-UA-Mobile": "?0",
        "Sec-CH-UA-Platform": '"macOS"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
    }
    data = {
        "phoneNumber": phone_number
    }
    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            return True, "Requests Successfully Sent with {}".format(phone_number)
        else:
            return False, f"Failed to send request: {response.status_code} {response.text}"
    except Exception as e:
        return False, str(e)